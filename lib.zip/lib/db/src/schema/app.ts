import { pgTable, text, timestamp, real, boolean, serial, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// ── Rentals (P2P tool sharing) ──────────────────────────────────────────────
export const rentalsTable = pgTable("rentals", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  pricePerDay: real("price_per_day").notNull(),
  city: text("city").notNull(),
  phone: text("phone"),
  ownerId: text("owner_id").notNull(),
  ownerName: text("owner_name"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertRentalSchema = createInsertSchema(rentalsTable).omit({ id: true, createdAt: true });
export type InsertRental = z.infer<typeof insertRentalSchema>;
export type Rental = typeof rentalsTable.$inferSelect;

// ── Rental Comments ──────────────────────────────────────────────────────────
export const rentalCommentsTable = pgTable("rental_comments", {
  id: uuid("id").primaryKey().defaultRandom(),
  rentalId: uuid("rental_id").notNull().references(() => rentalsTable.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull(),
  userName: text("user_name"),
  text: text("text").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertRentalCommentSchema = createInsertSchema(rentalCommentsTable).omit({ id: true, createdAt: true });
export type InsertRentalComment = z.infer<typeof insertRentalCommentSchema>;
export type RentalComment = typeof rentalCommentsTable.$inferSelect;

// ── Garage Logs (car maintenance) ───────────────────────────────────────────
export const garageLogsTable = pgTable("garage_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull(),
  carModel: text("car_model").notNull(),
  serviceName: text("service_name").notNull(),
  mileage: text("mileage").notNull(),
  notes: text("notes"),
  date: text("date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertGarageLogSchema = createInsertSchema(garageLogsTable).omit({ id: true, createdAt: true });
export type InsertGarageLog = z.infer<typeof insertGarageLogSchema>;
export type GarageLog = typeof garageLogsTable.$inferSelect;

// ── Diagnose History ─────────────────────────────────────────────────────────
export const diagnoseHistoryTable = pgTable("diagnose_history", {
  id: uuid("id").primaryKey().defaultRandom(),
  query: text("query").notNull(),
  language: text("language").notNull(),
  steps: text("steps").array().notNull().default([]),
  severity: text("severity"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── Notifications ────────────────────────────────────────────────────────────
export const notificationsTable = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull(),
  text: text("text").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
