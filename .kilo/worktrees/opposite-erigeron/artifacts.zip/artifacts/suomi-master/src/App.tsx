import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { LanguageProvider } from './hooks/use-language';
import { Layout } from './components/layout';

import WorkshopPage from './pages/workshop';
import GaragePage from './pages/garage';
import RentalsPage from './pages/rentals';
import OutdoorsPage from './pages/outdoors';
import ProfilePage from './pages/profile';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={WorkshopPage} />
        <Route path="/garage" component={GaragePage} />
        <Route path="/rentals" component={RentalsPage} />
        <Route path="/outdoors" component={OutdoorsPage} />
        <Route path="/profile" component={ProfilePage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
