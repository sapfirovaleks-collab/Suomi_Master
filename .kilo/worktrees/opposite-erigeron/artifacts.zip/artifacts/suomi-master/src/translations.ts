export type Language = 'ru' | 'en' | 'fi';

export const translations = {
  ru: {
    nav: {
      workshop: 'Мастерская',
      garage: 'Гараж',
      rentals: 'Прокат',
      outdoors: 'Природа',
      profile: 'Профиль'
    },
    common: {
      loading: 'Загрузка...',
      error: 'Произошла ошибка',
      save: 'Сохранить',
      cancel: 'Отмена',
      loginRequired: 'Войдите в систему для доступа',
      login: 'Войти',
      logout: 'Выйти',
      add: 'Добавить',
      delete: 'Удалить',
      search: 'Поиск'
    },
    workshop: {
      title: 'Диагностика OBD2 / Симптомы',
      placeholder: 'Напр. P0171 или "стук в подвеске спереди справа при повороте"',
      analyzeBtn: 'Анализировать',
      severity: {
        low: 'Низкая',
        medium: 'Средняя',
        high: 'Высокая'
      },
      estCost: 'Примерная стоимость:',
      partsStores: 'Магазины автозапчастей:',
      history: 'История диагностики'
    },
    garage: {
      title: 'Журнал ТО',
      addEntry: 'Новая запись ТО',
      carModel: 'Модель авто (напр. Volvo V70)',
      serviceName: 'Что сделано (напр. Замена масла)',
      mileage: 'Пробег (км)',
      notes: 'Заметки (необязательно)',
      katsastus: {
        title: 'Техосмотр (Katsastus)',
        desc: 'Проверьте подвеску, тормоза и OBD2 перед визитом.'
      },
      ekorosk: {
        title: 'Утилизация',
        desc: 'Сдавайте старое масло и аккумуляторы в Ekorosk (Kokkola).'
      }
    },
    rentals: {
      title: 'Прокат инструмента',
      postListing: 'Разместить объявление',
      formTitle: 'Название инструмента',
      formPrice: 'Цена за сутки (€)',
      formCity: 'Город',
      formPhone: 'Телефон',
      call: 'Позвонить',
      whatsapp: 'WhatsApp',
      owner: 'Владелец:',
      comments: 'Комментарии',
      addComment: 'Написать комментарий...'
    },
    outdoors: {
      weather: 'Погода',
      wind: 'Ветер',
      waterTemp: 'Темп. воды',
      airTemp: 'Темп. воздуха',
      pressure: 'Давление',
      fishingIndex: 'Клев',
      fishingSpots: 'Рыбные места',
      spots: {
        perhonjoki: 'Perhonjoki (Лосось, Форель, Хариус)',
        trullevi: 'Trullevi / Ykspihlaja (Щука, Окунь)'
      },
      foraging: 'Совет грибника/ягодника',
      links: 'Полезные ссылки'
    },
    profile: {
      title: 'Профиль',
      notifications: 'Уведомления',
      noNotifications: 'Нет новых уведомлений'
    }
  },
  en: {
    nav: {
      workshop: 'Workshop',
      garage: 'Garage',
      rentals: 'Rentals',
      outdoors: 'Outdoors',
      profile: 'Profile'
    },
    common: {
      loading: 'Loading...',
      error: 'An error occurred',
      save: 'Save',
      cancel: 'Cancel',
      loginRequired: 'Log in to access this feature',
      login: 'Log in',
      logout: 'Log out',
      add: 'Add',
      delete: 'Delete',
      search: 'Search'
    },
    workshop: {
      title: 'OBD2 / Symptom Diagnostics',
      placeholder: 'e.g. P0171 or "clunking noise in front right suspension"',
      analyzeBtn: 'Analyze',
      severity: {
        low: 'Low',
        medium: 'Medium',
        high: 'High'
      },
      estCost: 'Est. cost:',
      partsStores: 'Auto parts stores:',
      history: 'Diagnosis History'
    },
    garage: {
      title: 'Maintenance Log',
      addEntry: 'New Service Entry',
      carModel: 'Car Model (e.g. Volvo V70)',
      serviceName: 'Service Done (e.g. Oil change)',
      mileage: 'Mileage (km)',
      notes: 'Notes (optional)',
      katsastus: {
        title: 'Inspection (Katsastus)',
        desc: 'Check suspension, brakes, and OBD2 before visiting.'
      },
      ekorosk: {
        title: 'Recycling',
        desc: 'Dispose of old oil and batteries at Ekorosk (Kokkola).'
      }
    },
    rentals: {
      title: 'Tool Rentals',
      postListing: 'Post a Listing',
      formTitle: 'Tool Name',
      formPrice: 'Price per day (€)',
      formCity: 'City',
      formPhone: 'Phone',
      call: 'Call',
      whatsapp: 'WhatsApp',
      owner: 'Owner:',
      comments: 'Comments',
      addComment: 'Write a comment...'
    },
    outdoors: {
      weather: 'Weather',
      wind: 'Wind',
      waterTemp: 'Water Temp',
      airTemp: 'Air Temp',
      pressure: 'Pressure',
      fishingIndex: 'Bite Index',
      fishingSpots: 'Fishing Spots',
      spots: {
        perhonjoki: 'Perhonjoki (Salmon, Trout, Grayling)',
        trullevi: 'Trullevi / Ykspihlaja (Pike, Perch)'
      },
      foraging: 'Foraging Tip',
      links: 'Useful Links'
    },
    profile: {
      title: 'Profile',
      notifications: 'Notifications',
      noNotifications: 'No new notifications'
    }
  },
  fi: {
    nav: {
      workshop: 'Huolto',
      garage: 'Autotalli',
      rentals: 'Vuokraus',
      outdoors: 'Luonto',
      profile: 'Profiili'
    },
    common: {
      loading: 'Ladataan...',
      error: 'Tapahtui virhe',
      save: 'Tallenna',
      cancel: 'Peruuta',
      loginRequired: 'Kirjaudu sisään käyttääksesi tätä',
      login: 'Kirjaudu sisään',
      logout: 'Kirjaudu ulos',
      add: 'Lisää',
      delete: 'Poista',
      search: 'Etsi'
    },
    workshop: {
      title: 'OBD2 / Oireiden vianmääritys',
      placeholder: 'esim. P0171 tai "kolinaa oikeassa etujousituksessa"',
      analyzeBtn: 'Analysoi',
      severity: {
        low: 'Matala',
        medium: 'Keskitaso',
        high: 'Korkea'
      },
      estCost: 'Arvioitu hinta:',
      partsStores: 'Varaosaliikkeet:',
      history: 'Vianmäärityshistoria'
    },
    garage: {
      title: 'Huoltokirja',
      addEntry: 'Uusi huoltomerkintä',
      carModel: 'Automalli (esim. Volvo V70)',
      serviceName: 'Tehty huolto (esim. Öljynvaihto)',
      mileage: 'Ajokilometrit (km)',
      notes: 'Muistiinpanot (valinnainen)',
      katsastus: {
        title: 'Katsastus',
        desc: 'Tarkista jousitus, jarrut ja OBD2 ennen käyntiä.'
      },
      ekorosk: {
        title: 'Kierrätys',
        desc: 'Vie vanhat öljyt ja akut Ekoroskiin (Kokkola).'
      }
    },
    rentals: {
      title: 'Työkaluvuokraus',
      postListing: 'Jätä ilmoitus',
      formTitle: 'Työkalun nimi',
      formPrice: 'Hinta per päivä (€)',
      formCity: 'Kaupunki',
      formPhone: 'Puhelin',
      call: 'Soita',
      whatsapp: 'WhatsApp',
      owner: 'Omistaja:',
      comments: 'Kommentit',
      addComment: 'Kirjoita kommentti...'
    },
    outdoors: {
      weather: 'Sää',
      wind: 'Tuuli',
      waterTemp: 'Veden lämpö',
      airTemp: 'Ilman lämpö',
      pressure: 'Paine',
      fishingIndex: 'Syöntiennuste',
      fishingSpots: 'Kalapaikat',
      spots: {
        perhonjoki: 'Perhonjoki (Lohi, Taimen, Harjus)',
        trullevi: 'Trullevi / Ykspihlaja (Hauki, Ahven)'
      },
      foraging: 'Keräilyvinkki',
      links: 'Hyödyllisiä linkkejä'
    },
    profile: {
      title: 'Profiili',
      notifications: 'Ilmoitukset',
      noNotifications: 'Ei uusia ilmoituksia'
    }
  }
};
