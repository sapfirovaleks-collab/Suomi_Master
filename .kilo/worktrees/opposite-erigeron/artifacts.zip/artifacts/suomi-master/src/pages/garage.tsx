import { useState } from 'react';
import { useTranslation } from '@/hooks/use-translation';
import { useAuth } from '@workspace/replit-auth-web';
import { useListGarageLogs, useAddGarageLog } from '@workspace/api-client-react';
import { Button, Input, Textarea, Card, CardContent, CardHeader, CardTitle, Badge } from '@/components/ui/core';
import { Car, FileText, Plus, ShieldCheck, Recycle, Calendar, MapPin, Wrench } from 'lucide-react';
import { motion } from 'framer-motion';

export default function GaragePage() {
  const t = useTranslation();
  const { isAuthenticated, login } = useAuth();
  const [isAdding, setIsAdding] = useState(false);

  const [form, setForm] = useState({
    car_model: '',
    service_name: '',
    mileage: '',
    notes: ''
  });

  const { data: logs, refetch } = useListGarageLogs({ query: { enabled: isAuthenticated } });
  const addLog = useAddGarageLog();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addLog.mutate({
      data: form
    }, {
      onSuccess: () => {
        setIsAdding(false);
        setForm({ car_model: '', service_name: '', mileage: '', notes: '' });
        refetch();
      }
    });
  };

  return (
    <div className="space-y-6 pb-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold font-mono text-primary uppercase tracking-tight flex items-center gap-2">
          <Car className="w-5 h-5" />
          {t.garage.title}
        </h2>
        {isAuthenticated && !isAdding && (
          <Button size="sm" onClick={() => setIsAdding(true)} className="gap-1 font-mono uppercase text-xs">
            <Plus className="w-4 h-4" /> {t.common.add}
          </Button>
        )}
      </div>

      {!isAuthenticated ? (
        <Card className="border-dashed border-2 border-border bg-transparent">
          <CardContent className="flex flex-col items-center justify-center p-8 text-center space-y-4">
            <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
              <FileText className="w-6 h-6 text-muted-foreground" />
            </div>
            <p className="text-sm text-muted-foreground">{t.common.loginRequired}</p>
            <Button onClick={login} variant="outline" className="font-mono uppercase">{t.common.login}</Button>
          </CardContent>
        </Card>
      ) : isAdding ? (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
          <Card className="border-t-4 border-t-secondary shadow-[0_8px_30px_rgb(0,0,0,0.4)]">
            <CardHeader className="pb-3 bg-secondary/5">
              <CardTitle className="text-sm uppercase tracking-widest text-secondary">{t.garage.addEntry}</CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Input 
                    placeholder={t.garage.carModel} 
                    value={form.car_model}
                    onChange={e => setForm({...form, car_model: e.target.value})}
                    required
                    className="font-mono bg-background/50"
                  />
                  <Input 
                    placeholder={t.garage.serviceName} 
                    value={form.service_name}
                    onChange={e => setForm({...form, service_name: e.target.value})}
                    required
                    className="font-mono bg-background/50"
                  />
                  <Input 
                    placeholder={t.garage.mileage} 
                    value={form.mileage}
                    onChange={e => setForm({...form, mileage: e.target.value})}
                    required
                    type="number"
                    className="font-mono bg-background/50"
                  />
                  <Textarea 
                    placeholder={t.garage.notes} 
                    value={form.notes}
                    onChange={e => setForm({...form, notes: e.target.value})}
                    className="font-mono bg-background/50 resize-none h-20"
                  />
                </div>
                <div className="flex gap-2">
                  <Button type="button" variant="ghost" className="flex-1 font-mono uppercase" onClick={() => setIsAdding(false)}>
                    {t.common.cancel}
                  </Button>
                  <Button type="submit" disabled={addLog.isPending} className="flex-1 font-mono uppercase bg-secondary text-secondary-foreground hover:bg-secondary/90">
                    {t.common.save}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      ) : (
        <div className="space-y-3">
          {logs?.map((log) => (
            <Card key={log.id} className="group hover:border-primary/50 transition-colors">
              <CardContent className="p-4 space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-base group-hover:text-primary transition-colors flex items-center gap-2">
                      <Wrench className="w-4 h-4 text-muted-foreground" />
                      {log.service_name}
                    </h4>
                    <p className="text-sm text-muted-foreground font-mono mt-1">{log.car_model}</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline" className="font-mono bg-background/50">
                      {log.mileage} km
                    </Badge>
                  </div>
                </div>
                {log.notes && (
                  <p className="text-sm text-muted-foreground bg-muted/20 p-2 rounded-sm border border-border/50">
                    {log.notes}
                  </p>
                )}
                <div className="flex items-center text-xs text-muted-foreground font-mono gap-1 pt-2 border-t border-border/50">
                  <Calendar className="w-3 h-3" />
                  {new Date(log.date).toLocaleDateString()}
                </div>
              </CardContent>
            </Card>
          ))}
          {logs?.length === 0 && (
            <div className="text-center py-8 text-muted-foreground font-mono text-sm border border-dashed border-border rounded-sm">
              No entries yet
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
        <Card className="bg-card">
          <CardContent className="p-4 space-y-2">
            <div className="flex items-center gap-2 text-primary font-bold uppercase tracking-tight">
              <ShieldCheck className="w-5 h-5" />
              {t.garage.katsastus.title}
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {t.garage.katsastus.desc}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-secondary/10 rounded-full blur-xl -translate-y-1/2 translate-x-1/2" />
          <CardContent className="p-4 space-y-2 relative z-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-secondary font-bold uppercase tracking-tight">
                <Recycle className="w-5 h-5" />
                {t.garage.ekorosk.title}
              </div>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {t.garage.ekorosk.desc}
            </p>
            <a href="https://www.ekorosk.fi" target="_blank" rel="noreferrer" className="text-xs font-mono text-secondary hover:underline flex items-center gap-1 pt-1">
              <MapPin className="w-3 h-3" /> Kokkola/Kronoby
            </a>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
