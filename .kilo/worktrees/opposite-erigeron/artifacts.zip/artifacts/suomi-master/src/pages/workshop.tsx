import { useState } from 'react';
import { useTranslation } from '@/hooks/use-translation';
import { useLanguage } from '@/hooks/use-language';
import { useDiagnose, useGetDiagnoseHistory } from '@workspace/api-client-react';
import { Button, Textarea, Card, CardContent, CardHeader, CardTitle, Badge } from '@/components/ui/core';
import { Activity, AlertTriangle, ArrowRight, ExternalLink, History, Loader2, Wrench } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function WorkshopPage() {
  const t = useTranslation();
  const { language } = useLanguage();
  const [query, setQuery] = useState('');
  
  const diagnose = useDiagnose();
  const { data: history, refetch } = useGetDiagnoseHistory();

  const handleAnalyze = () => {
    if (!query.trim()) return;
    diagnose.mutate({
      data: {
        query,
        language
      }
    }, {
      onSuccess: () => {
        refetch();
      }
    });
  };

  const getSeverityBadge = (severity?: string | null) => {
    if (!severity) return null;
    const lower = severity.toLowerCase();
    if (lower === 'high') return <Badge variant="destructive">{t.workshop.severity.high}</Badge>;
    if (lower === 'medium') return <Badge variant="secondary">{t.workshop.severity.medium}</Badge>;
    return <Badge>{t.workshop.severity.low}</Badge>;
  };

  return (
    <div className="space-y-6 pb-6">
      <div className="space-y-2">
        <h2 className="text-xl font-bold font-mono text-primary uppercase tracking-tight flex items-center gap-2">
          <Activity className="w-5 h-5" />
          {t.workshop.title}
        </h2>
        
        <Card className="border-t-4 border-t-primary shadow-[0_8px_30px_rgb(0,0,0,0.4)]">
          <CardContent className="pt-4 space-y-4">
            <Textarea 
              placeholder={t.workshop.placeholder}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="bg-background/50 font-mono text-sm resize-none"
              rows={3}
            />
            <Button 
              className="w-full font-mono font-bold tracking-wide uppercase gap-2" 
              onClick={handleAnalyze}
              disabled={!query.trim() || diagnose.isPending}
            >
              {diagnose.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wrench className="w-4 h-4" />}
              {t.workshop.analyzeBtn}
            </Button>
          </CardContent>
        </Card>
      </div>

      <AnimatePresence>
        {diagnose.data && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <Card className="border-l-4 border-l-secondary bg-secondary/5">
              <CardHeader className="pb-3 border-b-secondary/20">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg flex items-center gap-2 text-secondary">
                    <AlertTriangle className="w-5 h-5" />
                    {diagnose.data.status}
                  </CardTitle>
                  {getSeverityBadge(diagnose.data.severity)}
                </div>
              </CardHeader>
              <CardContent className="space-y-4 pt-4">
                <ul className="space-y-3">
                  {diagnose.data.steps.map((step, i) => (
                    <li key={i} className="flex gap-3 text-sm items-start">
                      <span className="text-secondary font-mono bg-secondary/10 w-6 h-6 rounded flex items-center justify-center shrink-0 mt-0.5">{i + 1}</span>
                      <span className="text-muted-foreground leading-relaxed">{step}</span>
                    </li>
                  ))}
                </ul>
                
                {diagnose.data.estimated_cost_eur && (
                  <div className="bg-background/50 p-3 rounded-sm border border-border flex items-center justify-between mt-4">
                    <span className="text-sm font-medium">{t.workshop.estCost}</span>
                    <span className="font-mono text-primary font-bold">{diagnose.data.estimated_cost_eur}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-2">
              <h3 className="text-sm font-bold text-muted-foreground uppercase">{t.workshop.partsStores}</h3>
              <div className="flex flex-wrap gap-2">
                <a href="https://motonet.fi" target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs bg-card border border-border px-3 py-2 rounded-sm hover:bg-muted transition-colors font-mono">
                  Motonet <ExternalLink className="w-3 h-3 text-muted-foreground" />
                </a>
                <a href="https://biltema.fi" target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs bg-card border border-border px-3 py-2 rounded-sm hover:bg-muted transition-colors font-mono">
                  Biltema <ExternalLink className="w-3 h-3 text-muted-foreground" />
                </a>
                <a href="https://trodo.fi" target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs bg-card border border-border px-3 py-2 rounded-sm hover:bg-muted transition-colors font-mono">
                  Trodo <ExternalLink className="w-3 h-3 text-muted-foreground" />
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {history && history.length > 0 && (
        <div className="space-y-3 pt-6 border-t border-border">
          <h3 className="text-sm font-bold text-muted-foreground uppercase flex items-center gap-2">
            <History className="w-4 h-4" />
            {t.workshop.history}
          </h3>
          <div className="space-y-3">
            {history.slice(0, 5).map((record) => (
              <Card key={record.id} className="bg-card hover:border-primary/50 transition-colors cursor-pointer" onClick={() => {
                setQuery(record.query);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}>
                <CardContent className="p-3 flex justify-between items-center gap-3">
                  <div className="truncate flex-1">
                    <p className="text-sm font-medium truncate">{record.query}</p>
                    <p className="text-xs text-muted-foreground font-mono mt-1">{new Date(record.created_at).toLocaleDateString()}</p>
                  </div>
                  {getSeverityBadge(record.severity)}
                  <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
