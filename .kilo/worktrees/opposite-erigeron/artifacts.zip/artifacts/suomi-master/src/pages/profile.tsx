import { useTranslation } from '@/hooks/use-translation';
import { useAuth } from '@workspace/replit-auth-web';
import { useListNotifications } from '@workspace/api-client-react';
import { Button, Card, CardContent } from '@/components/ui/core';
import { User as UserIcon, LogOut, Bell, LogIn, Mail } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { motion } from 'framer-motion';

export default function ProfilePage() {
  const t = useTranslation();
  const { user, isAuthenticated, login, logout, isLoading: authLoading } = useAuth();
  
  const { data: notifications } = useListNotifications({ query: { enabled: isAuthenticated } });

  if (authLoading) {
    return <div className="p-8 text-center text-muted-foreground font-mono">Loading...</div>;
  }

  if (!isAuthenticated) {
    return (
      <div className="h-[70vh] flex flex-col items-center justify-center max-w-sm mx-auto text-center space-y-6">
        <div className="w-20 h-20 rounded-full bg-muted/30 border-2 border-dashed border-border flex items-center justify-center">
          <UserIcon className="w-10 h-10 text-muted-foreground" />
        </div>
        <div>
          <h2 className="text-2xl font-bold font-mono tracking-tighter mb-2">SUOMI-MASTER</h2>
          <p className="text-muted-foreground text-sm leading-relaxed">
            {t.common.loginRequired}
          </p>
        </div>
        <Button onClick={login} className="w-full font-mono uppercase tracking-widest py-6 shadow-[0_0_20px_hsl(var(--primary)/0.3)] gap-2">
          <LogIn className="w-5 h-5" />
          {t.common.login}
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold font-mono text-primary uppercase tracking-tight flex items-center gap-2">
          <UserIcon className="w-5 h-5" />
          {t.profile.title}
        </h2>
      </div>

      <Card className="bg-card border-t-4 border-t-primary overflow-hidden">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16 border-2 border-primary/20 rounded-sm">
              <AvatarImage src={user?.profileImageUrl || undefined} />
              <AvatarFallback className="rounded-sm bg-primary/10 text-primary font-mono text-xl">
                {user?.firstName?.[0] || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="font-bold text-xl leading-none mb-1">
                {user?.firstName} {user?.lastName}
              </h3>
              <p className="text-sm text-muted-foreground font-mono flex items-center gap-1">
                <Mail className="w-3 h-3" />
                {user?.email || 'No email provided'}
              </p>
            </div>
          </div>
          
          <Button onClick={logout} variant="outline" className="w-full mt-6 gap-2 font-mono uppercase text-destructive border-destructive/30 hover:bg-destructive/10 hover:text-destructive">
            <LogOut className="w-4 h-4" /> {t.common.logout}
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
          <Bell className="w-4 h-4" /> {t.profile.notifications}
        </h3>
        
        {notifications && notifications.length > 0 ? (
          <div className="space-y-2">
            {notifications.map((notif) => (
              <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} key={notif.id}>
                <Card className={`bg-card ${!notif.read ? 'border-l-2 border-l-primary' : ''}`}>
                  <CardContent className="p-4 flex gap-3">
                    <div className="w-2 h-2 rounded-full mt-1.5 shrink-0 bg-primary" style={{ opacity: notif.read ? 0 : 1 }} />
                    <div>
                      <p className="text-sm leading-relaxed">{notif.text}</p>
                      <p className="text-[10px] text-muted-foreground font-mono mt-2">
                        {new Date(notif.created_at).toLocaleString()}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-10 border border-dashed border-border rounded-sm bg-card">
            <Bell className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-sm font-mono text-muted-foreground">{t.profile.noNotifications}</p>
          </div>
        )}
      </div>
    </div>
  );
}
