export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center h-[60vh] text-center space-y-4">
      <h2 className="text-4xl font-bold font-mono text-muted-foreground">404</h2>
      <p className="text-muted-foreground">Page not found</p>
    </div>
  );
}
