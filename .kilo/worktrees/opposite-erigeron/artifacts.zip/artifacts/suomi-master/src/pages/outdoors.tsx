import { useTranslation } from '@/hooks/use-translation';
import { useLanguage } from '@/hooks/use-language';
import { useGetWeather } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle, Badge } from '@/components/ui/core';
import { Fish, CloudRain, Wind, ThermometerSun, Anchor, ExternalLink, Leaf, MapPin, Gauge } from 'lucide-react';
import { motion } from 'framer-motion';

export default function OutdoorsPage() {
  const t = useTranslation();
  const { language } = useLanguage();
  
  // Hardcoded to Kokkola for now as per spec
  const { data: weather, isLoading } = useGetWeather({ city: 'Kokkola' });

  const getFishingBadgeColor = (index: string) => {
    switch(index) {
      case 'excellent': return 'bg-secondary text-secondary-foreground border-secondary-border shadow-[0_0_10px_hsl(var(--secondary))]';
      case 'good': return 'bg-primary text-primary-foreground border-primary-border';
      case 'fair': return 'bg-yellow-600/20 text-yellow-500 border-yellow-600/30';
      case 'poor': return 'bg-destructive text-destructive-foreground border-destructive-border';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getFishingLabel = () => {
    if (!weather) return '';
    return weather[`fishing_label_${language}` as keyof typeof weather] as string || weather.fishing_index;
  };

  const getForagingTip = () => {
    if (!weather) return '';
    return weather[`foraging_tip_${language}` as keyof typeof weather] as string || '';
  };

  return (
    <div className="space-y-6 pb-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold font-mono text-secondary uppercase tracking-tight flex items-center gap-2">
          <Fish className="w-5 h-5" />
          {t.outdoors.title}
        </h2>
      </div>

      <Card className="border-t-4 border-t-secondary bg-gradient-to-b from-secondary/10 to-transparent overflow-hidden relative">
        <div className="absolute -right-10 -top-10 w-40 h-40 bg-secondary/20 rounded-full blur-3xl" />
        
        <CardContent className="p-5 relative z-10 space-y-6">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2 text-muted-foreground font-mono text-sm mb-1">
                <MapPin className="w-3 h-3" /> Kokkola
              </div>
              <h3 className="text-3xl font-bold font-mono tracking-tighter">
                {isLoading ? '--' : weather?.air_temp_c}°C
              </h3>
            </div>
            
            {weather && (
              <div className="text-right">
                <p className="text-[10px] uppercase font-bold text-muted-foreground mb-1 tracking-widest">{t.outdoors.fishingIndex}</p>
                <div className={`px-3 py-1 rounded-sm border font-bold text-sm uppercase tracking-wide inline-block ${getFishingBadgeColor(weather.fishing_index)}`}>
                  {getFishingLabel()}
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2 pt-4 border-t border-secondary/20">
            <div className="bg-background/40 p-2 rounded-sm border border-secondary/10 flex flex-col items-center justify-center text-center">
              <Wind className="w-4 h-4 text-secondary mb-1" />
              <span className="text-[10px] text-muted-foreground uppercase tracking-widest">{t.outdoors.wind}</span>
              <span className="font-mono text-sm font-bold">{isLoading ? '-' : weather?.wind_ms} m/s</span>
            </div>
            <div className="bg-background/40 p-2 rounded-sm border border-secondary/10 flex flex-col items-center justify-center text-center">
              <ThermometerSun className="w-4 h-4 text-primary mb-1" />
              <span className="text-[10px] text-muted-foreground uppercase tracking-widest">{t.outdoors.waterTemp}</span>
              <span className="font-mono text-sm font-bold">{isLoading ? '-' : weather?.water_temp_c}°C</span>
            </div>
            <div className="bg-background/40 p-2 rounded-sm border border-secondary/10 flex flex-col items-center justify-center text-center">
              <Gauge className="w-4 h-4 text-muted-foreground mb-1" />
              <span className="text-[10px] text-muted-foreground uppercase tracking-widest">{t.outdoors.pressure}</span>
              <span className="font-mono text-sm font-bold">{isLoading ? '-' : weather?.pressure_hpa}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
          <Anchor className="w-4 h-4" /> {t.outdoors.fishingSpots}
        </h3>
        
        <Card className="bg-card hover:border-secondary/50 transition-colors">
          <CardContent className="p-4 flex items-start gap-3">
            <div className="w-8 h-8 rounded bg-secondary/10 flex items-center justify-center shrink-0">
              <span className="font-mono font-bold text-secondary">01</span>
            </div>
            <div>
              <h4 className="font-bold text-base mb-1 leading-tight">{t.outdoors.spots.perhonjoki.split('(')[0]}</h4>
              <p className="text-xs text-muted-foreground font-mono">({t.outdoors.spots.perhonjoki.split('(')[1]}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card hover:border-secondary/50 transition-colors">
          <CardContent className="p-4 flex items-start gap-3">
            <div className="w-8 h-8 rounded bg-secondary/10 flex items-center justify-center shrink-0">
              <span className="font-mono font-bold text-secondary">02</span>
            </div>
            <div>
              <h4 className="font-bold text-base mb-1 leading-tight">{t.outdoors.spots.trullevi.split('(')[0]}</h4>
              <p className="text-xs text-muted-foreground font-mono">({t.outdoors.spots.trullevi.split('(')[1]}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {getForagingTip() && (
        <Card className="border-l-4 border-l-primary bg-primary/5">
          <CardContent className="p-4 flex gap-3 items-start">
            <Leaf className="w-5 h-5 text-primary shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-xs uppercase tracking-widest text-primary mb-1">{t.outdoors.foraging}</h4>
              <p className="text-sm text-foreground/90 leading-relaxed">
                {getForagingTip()}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-3 pt-2">
        <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest">{t.outdoors.links}</h3>
        <div className="grid grid-cols-2 gap-2">
          <a href="https://www.eraluvat.fi" target="_blank" rel="noreferrer" className="bg-card border border-border p-3 rounded-sm flex flex-col items-center justify-center gap-2 hover:bg-muted/50 transition-colors text-center">
            <Fish className="w-5 h-5 text-muted-foreground" />
            <span className="text-xs font-mono font-bold">Eräluvat.fi</span>
          </a>
          <a href="https://www.ilmatieteenlaitos.fi" target="_blank" rel="noreferrer" className="bg-card border border-border p-3 rounded-sm flex flex-col items-center justify-center gap-2 hover:bg-muted/50 transition-colors text-center">
            <CloudRain className="w-5 h-5 text-muted-foreground" />
            <span className="text-xs font-mono font-bold">FMI Weather</span>
          </a>
        </div>
      </div>
    </div>
  );
}
