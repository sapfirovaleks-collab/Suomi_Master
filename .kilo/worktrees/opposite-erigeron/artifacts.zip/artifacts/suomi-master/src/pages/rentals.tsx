import { useState } from 'react';
import { useTranslation } from '@/hooks/use-translation';
import { useAuth } from '@workspace/replit-auth-web';
import { useListRentals, useCreateRental, useGetRentalComments, useAddRentalComment } from '@workspace/api-client-react';
import { Button, Input, Card, CardContent, CardHeader, CardTitle, Badge } from '@/components/ui/core';
import { Handshake, Search, MapPin, Phone, MessageSquare, Plus, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

function RentalComments({ rentalId }: { rentalId: string }) {
  const t = useTranslation();
  const { isAuthenticated } = useAuth();
  const [text, setText] = useState('');
  
  const { data: comments, refetch } = useGetRentalComments(rentalId);
  const addComment = useAddRentalComment();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    
    addComment.mutate({
      id: rentalId,
      data: { text }
    }, {
      onSuccess: () => {
        setText('');
        refetch();
      }
    });
  };

  return (
    <div className="mt-4 space-y-3 pt-3 border-t border-border/50">
      <h5 className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-1">
        <MessageSquare className="w-3 h-3" /> {t.rentals.comments} ({comments?.length || 0})
      </h5>
      
      {comments && comments.length > 0 && (
        <div className="space-y-2 max-h-32 overflow-y-auto pr-1 text-sm">
          {comments.map((c) => (
            <div key={c.id} className="bg-background/50 rounded-sm p-2 border border-border/30">
              <div className="flex justify-between items-center mb-1">
                <span className="font-bold text-xs text-primary">{c.user_name || 'User'}</span>
                <span className="text-[10px] text-muted-foreground font-mono">{new Date(c.created_at).toLocaleDateString()}</span>
              </div>
              <p className="text-muted-foreground text-xs">{c.text}</p>
            </div>
          ))}
        </div>
      )}

      {isAuthenticated && (
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input 
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t.rentals.addComment}
            className="h-8 text-xs font-mono bg-background/50"
          />
          <Button type="submit" size="sm" className="h-8 shrink-0" disabled={addComment.isPending || !text.trim()}>
            {addComment.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <MessageSquare className="w-3 h-3" />}
          </Button>
        </form>
      )}
    </div>
  );
}

export default function RentalsPage() {
  const t = useTranslation();
  const { isAuthenticated, login } = useAuth();
  
  const [search, setSearch] = useState('');
  const [city, setCity] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});

  const [form, setForm] = useState({
    title: '',
    price_per_day: '',
    city: '',
    phone: ''
  });

  const { data: rentals, refetch } = useListRentals({ search, city });
  const createRental = useCreateRental();

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createRental.mutate({
      data: {
        ...form,
        price_per_day: Number(form.price_per_day)
      }
    }, {
      onSuccess: () => {
        setIsAdding(false);
        setForm({ title: '', price_per_day: '', city: '', phone: '' });
        refetch();
      }
    });
  };

  const toggleComments = (id: string) => {
    setExpandedComments(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6 pb-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold font-mono text-primary uppercase tracking-tight flex items-center gap-2">
          <Handshake className="w-5 h-5" />
          {t.rentals.title}
        </h2>
        {isAuthenticated && !isAdding && (
          <Button size="sm" onClick={() => setIsAdding(true)} className="gap-1 font-mono uppercase text-xs bg-primary text-primary-foreground hover:bg-primary/90">
            <Plus className="w-4 h-4" /> {t.common.add}
          </Button>
        )}
      </div>

      {isAdding && isAuthenticated && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
          <Card className="border-t-4 border-t-primary shadow-[0_8px_30px_rgb(0,0,0,0.4)] mb-6">
            <CardHeader className="pb-3 bg-primary/5">
              <CardTitle className="text-sm uppercase tracking-widest text-primary">{t.rentals.postListing}</CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <form onSubmit={handleCreate} className="space-y-4">
                <div className="space-y-2">
                  <Input placeholder={t.rentals.formTitle} required value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="font-mono bg-background/50" />
                  <div className="grid grid-cols-2 gap-2">
                    <Input placeholder={t.rentals.formPrice} required type="number" min="1" value={form.price_per_day} onChange={e => setForm({...form, price_per_day: e.target.value})} className="font-mono bg-background/50" />
                    <Input placeholder={t.rentals.formCity} required value={form.city} onChange={e => setForm({...form, city: e.target.value})} className="font-mono bg-background/50" />
                  </div>
                  <Input placeholder={t.rentals.formPhone} value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} className="font-mono bg-background/50" />
                </div>
                <div className="flex gap-2">
                  <Button type="button" variant="ghost" className="flex-1 font-mono uppercase" onClick={() => setIsAdding(false)}>
                    {t.common.cancel}
                  </Button>
                  <Button type="submit" disabled={createRental.isPending} className="flex-1 font-mono uppercase">
                    {t.common.save}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {!isAdding && (
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input 
              placeholder={t.common.search} 
              value={search} 
              onChange={e => setSearch(e.target.value)}
              className="pl-9 font-mono bg-card border-border"
            />
          </div>
          <div className="relative w-32 shrink-0">
            <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input 
              placeholder="City" 
              value={city} 
              onChange={e => setCity(e.target.value)}
              className="pl-9 font-mono bg-card border-border"
            />
          </div>
        </div>
      )}

      <div className="space-y-4">
        {rentals?.map((rental) => (
          <Card key={rental.id} className="overflow-hidden border-border bg-card">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-bold text-lg text-foreground">{rental.title}</h3>
                <Badge variant="default" className="font-mono bg-primary text-primary-foreground border-primary-border shrink-0 text-sm">
                  {rental.price_per_day} €/d
                </Badge>
              </div>
              
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <span className="flex items-center gap-1 font-mono">
                  <MapPin className="w-3 h-3" /> {rental.city}
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
                  {rental.owner_name}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {rental.phone ? (
                  <>
                    <a href={`tel:${rental.phone}`} className="inline-flex items-center justify-center rounded-sm text-sm font-semibold transition-all focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 active:scale-95 border border-border bg-transparent hover:bg-muted/50 text-foreground h-8 px-3 text-xs flex-1 gap-2 font-mono">
                      <Phone className="w-3 h-3" /> {t.rentals.call}
                    </a>
                    <a href={`https://wa.me/${rental.phone.replace(/[^0-9]/g, '')}`} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center rounded-sm text-sm font-semibold transition-all focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 active:scale-95 border bg-transparent text-foreground h-8 px-3 text-xs flex-1 gap-2 font-mono border-secondary/50 text-secondary hover:bg-secondary/10">
                      <MessageSquare className="w-3 h-3" /> WA
                    </a>
                  </>
                ) : (
                  <Button variant="outline" size="sm" className="w-full gap-2 font-mono text-muted-foreground" disabled>
                    <Phone className="w-3 h-3" /> No phone provided
                  </Button>
                )}
                <Button variant="ghost" size="icon" className="shrink-0 text-muted-foreground" onClick={() => toggleComments(rental.id)}>
                  <MessageSquare className="w-4 h-4" />
                </Button>
              </div>

              <AnimatePresence>
                {expandedComments[rental.id] && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
                    <RentalComments rentalId={rental.id} />
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        ))}
        {rentals?.length === 0 && (
          <div className="text-center py-12 text-muted-foreground font-mono text-sm border border-dashed border-border rounded-sm">
            No tools found
          </div>
        )}
      </div>
    </div>
  );
}
