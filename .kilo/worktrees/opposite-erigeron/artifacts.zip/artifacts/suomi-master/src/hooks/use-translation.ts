import { useLanguage } from '@/hooks/use-language';
import { translations } from '@/translations';

export function useTranslation() {
  const { language } = useLanguage();
  return translations[language];
}
