import { Link, useLocation } from 'wouter';
import { Wrench, Car, Handshake, Fish, User as UserIcon } from 'lucide-react';
import { useLanguage } from '@/hooks/use-language';
import { useTranslation } from '@/hooks/use-translation';
import { Language } from '@/translations';
import { cn } from './ui/core';

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { language, setLanguage } = useLanguage();
  const t = useTranslation();

  const navItems = [
    { href: '/', icon: Wrench, label: t.nav.workshop },
    { href: '/garage', icon: Car, label: t.nav.garage },
    { href: '/rentals', icon: Handshake, label: t.nav.rentals },
    { href: '/outdoors', icon: Fish, label: t.nav.outdoors },
    { href: '/profile', icon: UserIcon, label: t.nav.profile },
  ];

  return (
    <div className="min-h-[100dvh] max-w-md mx-auto relative bg-background pb-20 flex flex-col font-sans">
      <div className="texture-overlay" />
      
      {/* Top bar */}
      <header className="sticky top-0 z-40 bg-background/90 backdrop-blur-md border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-primary rounded-sm flex items-center justify-center text-primary-foreground font-bold font-mono text-sm shadow-sm">
            S
          </div>
          <h1 className="font-bold text-lg tracking-tight uppercase">Suomi<span className="text-primary">-Master</span></h1>
        </div>
        
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value as Language)}
          className="bg-card border border-border rounded-sm px-2 py-1 text-xs font-mono font-medium focus:outline-none focus:ring-1 focus:ring-primary appearance-none cursor-pointer hover:bg-muted/50 transition-colors"
        >
          <option value="ru">RU</option>
          <option value="en">EN</option>
          <option value="fi">FI</option>
        </select>
      </header>

      {/* Main Content */}
      <main className="flex-1 relative z-10 w-full p-4 overflow-y-auto">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border shadow-[0_-4px_20px_rgba(0,0,0,0.5)]">
        <div className="max-w-md mx-auto flex items-center justify-around">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== '/' && location.startsWith(item.href));
            const Icon = item.icon;
            
            return (
              <Link key={item.href} href={item.href} className="flex-1">
                <div className={cn(
                  "flex flex-col items-center justify-center py-3 px-2 gap-1 cursor-pointer transition-all relative overflow-hidden",
                  isActive ? "text-primary" : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
                )}>
                  <Icon className={cn("w-5 h-5 transition-transform", isActive ? "scale-110" : "scale-100")} strokeWidth={isActive ? 2.5 : 2} />
                  <span className="text-[10px] font-medium tracking-tight truncate w-full text-center">{item.label}</span>
                  {isActive && (
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-1 bg-primary rounded-b-sm shadow-[0_0_8px_hsl(var(--primary))]" />
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
