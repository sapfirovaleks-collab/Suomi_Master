import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { diagnoseHistoryTable } from "@workspace/db";
import { DiagnoseBody, DiagnoseResponse, GetDiagnoseHistoryResponse } from "@workspace/api-zod";
import { desc } from "drizzle-orm";

const router: IRouter = Router();

// Keyword-based diagnosis logic (fallback when no AI integration)
function generateSteps(query: string, language: "ru" | "en" | "fi"): { steps: string[]; severity: string } {
  const q = query.toLowerCase();

  const isObd = /p\d{4}|b\d{4}|c\d{4}|u\d{4}/i.test(query);
  const hasEngineKnock = /knock|стук|kolina|tapping|ping/i.test(q);
  const hasBrake = /brake|тормоз|jarru/i.test(q);
  const hasOil = /oil|масло|öljy|leak|течь|vuoto/i.test(q);
  const hasBattery = /battery|акку|akku|start|запуск|käynnistys/i.test(q);
  const hasOverheat = /overheat|перегрев|ylikuumene|temperature|темпера/i.test(q);
  const hasTire = /tire|tyre|шин|rengas|flat|прокол/i.test(q);

  let severity = "medium";
  let steps: { ru: string[]; en: string[]; fi: string[] };

  if (isObd) {
    severity = "medium";
    steps = {
      ru: [
        `1. Подключите OBD2-сканер и запишите полный код ошибки (${query.match(/[PBCU]\d{4}/i)?.[0] || query}).`,
        "2. Проверьте соединения датчиков и жгуты проводов вблизи указанного узла.",
        "3. Сбросьте ошибку и проведите тест-драйв — если код вернётся, замените датчик.",
        "4. Уточните артикул детали на сайте Motonet или Biltema по модели авто.",
        "5. После замены снова считайте ошибки и убедитесь, что код не повторяется.",
      ],
      en: [
        `1. Connect an OBD2 scanner and record the full fault code (${query.match(/[PBCU]\d{4}/i)?.[0] || query}).`,
        "2. Inspect sensor connections and wiring harnesses near the affected component.",
        "3. Clear the code and test drive — if it returns, replace the faulty sensor.",
        "4. Look up the part number on Motonet or Biltema for your vehicle model.",
        "5. After replacement, re-scan to confirm the code does not return.",
      ],
      fi: [
        `1. Kytke OBD2-lukija ja kirjaa vikakoodi (${query.match(/[PBCU]\d{4}/i)?.[0] || query}) ylös.`,
        "2. Tarkista anturin liitokset ja johdotus kyseisen osan läheltä.",
        "3. Nollaa vikakoodi ja aja koeajo — jos koodi palaa, vaihda anturi.",
        "4. Hae varaosanumero Motonetistä tai Biltemasta ajoneuvon mallin mukaan.",
        "5. Vaihdon jälkeen lue viat uudelleen ja varmista, ettei koodi toistu.",
      ],
    };
  } else if (hasEngineKnock) {
    severity = "high";
    steps = {
      ru: [
        "1. Немедленно заглушите двигатель — стук может означать критический износ вкладышей.",
        "2. Проверьте уровень и давление масла (должен быть в норме).",
        "3. Определите источник стука: сверху (клапаны, ГРМ) или снизу (коленвал, поршни).",
        "4. При стуке снизу — не запускайте двигатель до диагностики у механика.",
        "5. Обратитесь на СТО; для замены вкладышей потребуется частичная разборка мотора.",
      ],
      en: [
        "1. Stop the engine immediately — knocking may indicate critical bearing wear.",
        "2. Check oil level and pressure — must be within spec.",
        "3. Identify knock source: top (valves, timing) or bottom (crankshaft, pistons).",
        "4. If knocking from below — do not restart until a mechanic inspects.",
        "5. Have a workshop inspect; bearing replacement requires partial engine disassembly.",
      ],
      fi: [
        "1. Sammuta moottori välittömästi — kolina voi tarkoittaa kriittistä laakerikulumista.",
        "2. Tarkista öljyn pinta ja paine — on oltava normaalilla tasolla.",
        "3. Selvitä kolina-alue: ylhäältä (venttiilit, jakohihna) vai alhaalta (kampiakseli).",
        "4. Jos kolina kuuluu alhaalta — älä käynnistä ennen mekaanikon tarkastusta.",
        "5. Vie korjaamolle; laakerin vaihto vaatii moottorin osittaista purkamista.",
      ],
    };
  } else if (hasBrake) {
    severity = "high";
    steps = {
      ru: [
        "1. Проверьте уровень тормозной жидкости в бачке под капотом.",
        "2. Осмотрите тормозные колодки через диск — если толщина < 3 мм, замените.",
        "3. Проверьте тормозные диски на наличие борозд, трещин или перегрева.",
        "4. Прокачайте тормозную систему, если педаль мягкая или проваливается.",
        "5. Новые колодки и диски доступны в Motonet и Biltema по VIN-коду.",
      ],
      en: [
        "1. Check brake fluid level in the reservoir under the hood.",
        "2. Inspect brake pads through the disc — if thickness < 3mm, replace them.",
        "3. Inspect brake discs for grooves, cracks, or heat damage.",
        "4. Bleed the brake system if the pedal feels soft or spongy.",
        "5. Pads and discs are available at Motonet and Biltema by VIN lookup.",
      ],
      fi: [
        "1. Tarkista jarrunesteen pinta konepellin alla olevasta säiliöstä.",
        "2. Tarkista jarrupalat kiekon läpi — jos paksuus < 3mm, vaihda.",
        "3. Tarkista jarrulevyt urien, halkeamien tai ylikuumenemisen varalta.",
        "4. Ilmaa jarrujärjestelmä, jos poljin tuntuu pehmeältä tai uppoaa.",
        "5. Palat ja levyt löydät Motonetistä ja Biltemasta VIN-haulla.",
      ],
    };
  } else if (hasBattery) {
    severity = "medium";
    steps = {
      ru: [
        "1. Проверьте напряжение аккумулятора мультиметром: норма 12.4–12.7 В в покое.",
        "2. Осмотрите клеммы на наличие окисления — при необходимости зачистите.",
        "3. Проверьте зарядку генератора при работающем двигателе (должно быть 13.8–14.4 В).",
        "4. Если АКБ не держит заряд после 3 лет эксплуатации — замените.",
        "5. Новые аккумуляторы Bosch и Varta доступны в Motonet, Biltema, Trodo.",
      ],
      en: [
        "1. Check battery voltage with a multimeter: normal is 12.4–12.7V at rest.",
        "2. Inspect terminals for corrosion — clean with a wire brush if needed.",
        "3. Check alternator output at idle: should be 13.8–14.4V.",
        "4. If battery fails to hold charge after 3 years — replace it.",
        "5. Bosch and Varta batteries available at Motonet, Biltema, Trodo.",
      ],
      fi: [
        "1. Mittaa akun jännite yleismittarilla: normaali lepoarvo 12,4–12,7 V.",
        "2. Tarkista liittimet korroosiolta — puhdista tarvittaessa teräsharjalla.",
        "3. Tarkista laturin latausjännite käynnissä: pitäisi olla 13,8–14,4 V.",
        "4. Jos akku ei pidä varausta 3 vuoden käytön jälkeen — vaihda.",
        "5. Bosch- ja Varta-akut löydät Motonetistä, Biltemasta ja Trodosta.",
      ],
    };
  } else if (hasOil) {
    severity = "high";
    steps = {
      ru: [
        "1. Определите источник течи: крышка клапанов, поддон картера или сальники.",
        "2. Обезжирьте область вокруг течи и запустите двигатель для точной локализации.",
        "3. Замените уплотнительные прокладки или сальники по месту течи.",
        "4. Долейте масло до нормального уровня (между MIN и MAX на щупе).",
        "5. Прокладки и герметики доступны в Motonet и Biltema.",
      ],
      en: [
        "1. Identify leak source: valve cover, oil pan gasket, or seals.",
        "2. Clean and degrease the area, run the engine to pinpoint the leak precisely.",
        "3. Replace the gasket or seal at the leak point.",
        "4. Top up oil to proper level (between MIN and MAX on dipstick).",
        "5. Gaskets and sealants available at Motonet and Biltema.",
      ],
      fi: [
        "1. Paikanna vuodon lähde: venttiilikansitiivis, öljypohja vai tiivisteet.",
        "2. Puhdista alue rasvanpoistoaineella ja käynnistä moottori vuodon tarkkaa paikantamista varten.",
        "3. Vaihda tiivistysaine tai tiiviste vuotokohtaan.",
        "4. Lisää öljy oikealle tasolle (mittatikun MIN ja MAX välille).",
        "5. Tiivisteet ja tiivistemassaa löydät Motonetistä ja Biltemasta.",
      ],
    };
  } else if (hasOverheat) {
    severity = "high";
    steps = {
      ru: [
        "1. Немедленно остановитесь и заглушите двигатель — не открывайте крышку радиатора!",
        "2. Дайте двигателю остыть 20–30 минут перед любыми действиями.",
        "3. Проверьте уровень охлаждающей жидкости в расширительном бачке.",
        "4. Осмотрите шланги охлаждения на предмет трещин и хомуты на надёжность.",
        "5. Если система в норме, проверьте термостат и помпу — вероятно, требует замены.",
      ],
      en: [
        "1. Pull over and shut off the engine immediately — do NOT open the radiator cap!",
        "2. Allow the engine to cool for 20–30 minutes before any action.",
        "3. Check coolant level in the expansion tank.",
        "4. Inspect coolant hoses for cracks and clamps for tightness.",
        "5. If the system looks normal, check the thermostat and water pump — likely needs replacement.",
      ],
      fi: [
        "1. Pysähdy ja sammuta moottori välittömästi — ÄLÄ avaa jäähdyttimen korkkia!",
        "2. Anna moottorin jäähtyä 20–30 minuuttia ennen toimenpiteitä.",
        "3. Tarkista jäähdytysnesteen pinta paisuntasäiliöstä.",
        "4. Tarkista jäähdytysletkut halkeamien ja kiristimien varalta.",
        "5. Jos järjestelmä näyttää kunnossa, tarkista termostaatti ja vesipumppu — todennäköisesti tarvitaan vaihto.",
      ],
    };
  } else if (hasTire) {
    severity = "low";
    steps = {
      ru: [
        "1. Убедитесь в безопасности места — съедьте на обочину, включите аварийку.",
        "2. Замените спущенное колесо на запаску (домкрат под кузовом или в багажнике).",
        "3. Затяните гайки крест-накрест, затяжка 110–120 Нм для большинства легковых.",
        "4. На запаске ограничение скорости 80 км/ч — обратитесь в шиномонтаж.",
        "5. Новые шины доступны в Motonet и Biltema, монтаж в любом шиномонтажном сервисе.",
      ],
      en: [
        "1. Move to safety — pull to the roadside, turn on hazard lights.",
        "2. Replace the flat with the spare (jack stored under the body or in the trunk).",
        "3. Tighten lug nuts in a cross pattern, torque to 110–120 Nm for most cars.",
        "4. Speed limit on spare is 80 km/h — visit a tire shop soon.",
        "5. New tires available at Motonet and Biltema, fitting at any tyre shop.",
      ],
      fi: [
        "1. Siirry turvalliseen paikkaan — aja tien reunaan, laita hätävilkut päälle.",
        "2. Vaihda lytty rengas varalle (tunkit alla tai tavaratilassa).",
        "3. Kiristä mutterit ristiin, vääntömomentti 110–120 Nm useimmille autoille.",
        "4. Varapyörän nopeusrajoitus 80 km/h — käy rengasliikkeessä pian.",
        "5. Uudet renkaat Motonetistä ja Biltemasta, asennus missä tahansa rengasliikkeessä.",
      ],
    };
  } else {
    // Generic
    severity = "medium";
    steps = {
      ru: [
        "1. Считайте коды ошибок OBD2-сканером — это сузит диагностику.",
        "2. Осмотрите визуально подозрительный узел: проводка, шланги, крепления.",
        "3. Проверьте уровни жидкостей: масло, охлаждающая жидкость, тормозная.",
        "4. Уточните симптомы: при какой скорости, температуре, нагрузке возникает проблема.",
        "5. Если самостоятельно выявить не удаётся — обратитесь на СТО или в Motonet за диагностикой.",
      ],
      en: [
        "1. Read OBD2 fault codes with a scanner — this narrows the diagnosis.",
        "2. Visually inspect the suspected component: wiring, hoses, mounting.",
        "3. Check fluid levels: oil, coolant, brake fluid.",
        "4. Note symptoms: at what speed, temperature, or load the problem occurs.",
        "5. If unable to diagnose yourself — visit a workshop or Motonet for a diagnostic check.",
      ],
      fi: [
        "1. Lue OBD2-vikakoodi lukijalla — tämä rajaa diagnosointia.",
        "2. Tarkasta epäilty osa silmämääräisesti: johdotus, letkut, kiinnikkeet.",
        "3. Tarkista nestetasot: öljy, jäähdytysneste, jarruneste.",
        "4. Kirjaa oireet: missä nopeudessa, lämpötilassa tai kuormassa ongelma ilmenee.",
        "5. Jos itse diagnoosi ei onnistu — käy korjaamolla tai Motonetissä diagnostiikkatarkastuksessa.",
      ],
    };
  }

  return { steps: steps[language] || steps.ru, severity };
}

router.post("/v1/diagnose", async (req, res): Promise<void> => {
  const parsed = DiagnoseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { query, language } = parsed.data;
  const lang = language as "ru" | "en" | "fi";
  const { steps, severity } = generateSteps(query, lang);

  // Save to history (no auth required)
  await db.insert(diagnoseHistoryTable).values({
    query,
    language,
    steps,
    severity,
  });

  const result = DiagnoseResponse.parse({
    status: "success",
    steps,
    severity,
    estimated_cost_eur:
      severity === "high" ? "200–800 €" :
      severity === "medium" ? "50–200 €" : "10–60 €",
  });

  res.json(result);
});

router.get("/v1/diagnose/history", async (_req, res): Promise<void> => {
  const history = await db
    .select()
    .from(diagnoseHistoryTable)
    .orderBy(desc(diagnoseHistoryTable.createdAt))
    .limit(20);

  const result = GetDiagnoseHistoryResponse.parse(
    history.map((h) => ({
      id: h.id,
      query: h.query,
      language: h.language,
      steps: h.steps,
      severity: h.severity ?? null,
      created_at: h.createdAt.toISOString(),
    }))
  );

  res.json(result);
});

export default router;
