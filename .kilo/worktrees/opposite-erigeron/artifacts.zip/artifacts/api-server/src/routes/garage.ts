import { Router, type IRouter } from "express";
import { db, garageLogsTable } from "@workspace/db";
import {
  ListGarageLogsResponse,
  AddGarageLogBody,
  AddGarageLogResponse,
} from "@workspace/api-zod";
import { eq, desc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/v1/garage", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const logs = await db
    .select()
    .from(garageLogsTable)
    .where(eq(garageLogsTable.userId, req.user.id))
    .orderBy(desc(garageLogsTable.createdAt));

  const result = ListGarageLogsResponse.parse(
    logs.map((l) => ({
      id: l.id,
      user_id: l.userId,
      car_model: l.carModel,
      service_name: l.serviceName,
      mileage: l.mileage,
      notes: l.notes ?? null,
      date: l.date,
      created_at: l.createdAt.toISOString(),
    }))
  );

  res.json(result);
});

router.post("/v1/garage", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const parsed = AddGarageLogBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const today = new Date().toLocaleDateString("fi-FI"); // dd.mm.yyyy

  const [log] = await db
    .insert(garageLogsTable)
    .values({
      userId: req.user.id,
      carModel: parsed.data.car_model,
      serviceName: parsed.data.service_name,
      mileage: parsed.data.mileage,
      notes: parsed.data.notes ?? null,
      date: today,
    })
    .returning();

  const result = AddGarageLogResponse.parse({
    id: log.id,
    user_id: log.userId,
    car_model: log.carModel,
    service_name: log.serviceName,
    mileage: log.mileage,
    notes: log.notes ?? null,
    date: log.date,
    created_at: log.createdAt.toISOString(),
  });

  res.status(201).json(result);
});

export default router;
