import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import diagnoseRouter from "./diagnose";
import rentalsRouter from "./rentals";
import garageRouter from "./garage";
import weatherRouter from "./weather";
import notificationsRouter from "./notifications";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(diagnoseRouter);
router.use(rentalsRouter);
router.use(garageRouter);
router.use(weatherRouter);
router.use(notificationsRouter);

export default router;
