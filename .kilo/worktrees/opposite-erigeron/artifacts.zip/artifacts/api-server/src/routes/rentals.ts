import { Router, type IRouter } from "express";
import { db, rentalsTable, rentalCommentsTable, notificationsTable } from "@workspace/db";
import {
  ListRentalsResponse,
  CreateRentalBody,
  CreateRentalResponse,
  DeleteRentalParams,
  DeleteRentalResponse,
  GetRentalCommentsParams,
  GetRentalCommentsResponse,
  AddRentalCommentParams,
  AddRentalCommentBody,
  AddRentalCommentResponse,
} from "@workspace/api-zod";
import { eq, and, ilike, desc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/v1/rentals", async (req, res): Promise<void> => {
  const { search, city } = req.query as { search?: string; city?: string };

  let query = db.select().from(rentalsTable).$dynamic();

  const conditions = [];
  if (search) conditions.push(ilike(rentalsTable.title, `%${search}%`));
  if (city) conditions.push(ilike(rentalsTable.city, `%${city}%`));

  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }

  const rentals = await query.orderBy(desc(rentalsTable.createdAt));

  const result = ListRentalsResponse.parse(
    rentals.map((r) => ({
      id: r.id,
      title: r.title,
      price_per_day: r.pricePerDay,
      city: r.city,
      phone: r.phone ?? null,
      owner_id: r.ownerId,
      owner_name: r.ownerName ?? null,
      image_url: r.imageUrl ?? null,
      created_at: r.createdAt.toISOString(),
    }))
  );

  res.json(result);
});

router.post("/v1/rentals", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const parsed = CreateRentalBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { title, price_per_day, city, phone } = parsed.data;

  const [rental] = await db
    .insert(rentalsTable)
    .values({
      title,
      pricePerDay: price_per_day,
      city,
      phone: phone ?? null,
      ownerId: req.user.id,
      ownerName: [req.user.firstName, req.user.lastName].filter(Boolean).join(" ") || req.user.email || "User",
    })
    .returning();

  const result = CreateRentalResponse.parse({
    id: rental.id,
    title: rental.title,
    price_per_day: rental.pricePerDay,
    city: rental.city,
    phone: rental.phone ?? null,
    owner_id: rental.ownerId,
    owner_name: rental.ownerName ?? null,
    image_url: rental.imageUrl ?? null,
    created_at: rental.createdAt.toISOString(),
  });

  res.status(201).json(result);
});

router.delete("/v1/rentals/:id", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const params = DeleteRentalParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [rental] = await db
    .select()
    .from(rentalsTable)
    .where(eq(rentalsTable.id, params.data.id));

  if (!rental) {
    res.status(404).json({ error: "Rental not found" });
    return;
  }

  if (rental.ownerId !== req.user.id) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(rentalsTable).where(eq(rentalsTable.id, params.data.id));

  res.json(DeleteRentalResponse.parse({ status: "deleted" }));
});

router.get("/v1/rentals/:id/comments", async (req, res): Promise<void> => {
  const params = GetRentalCommentsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const comments = await db
    .select()
    .from(rentalCommentsTable)
    .where(eq(rentalCommentsTable.rentalId, params.data.id))
    .orderBy(rentalCommentsTable.createdAt);

  const result = GetRentalCommentsResponse.parse(
    comments.map((c) => ({
      id: c.id,
      rental_id: c.rentalId,
      user_id: c.userId,
      user_name: c.userName ?? null,
      text: c.text,
      created_at: c.createdAt.toISOString(),
    }))
  );

  res.json(result);
});

router.post("/v1/rentals/:id/comments", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const params = AddRentalCommentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = AddRentalCommentBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [rental] = await db
    .select()
    .from(rentalsTable)
    .where(eq(rentalsTable.id, params.data.id));

  if (!rental) {
    res.status(404).json({ error: "Rental not found" });
    return;
  }

  const userName =
    [req.user.firstName, req.user.lastName].filter(Boolean).join(" ") || req.user.email || "User";

  const [comment] = await db
    .insert(rentalCommentsTable)
    .values({
      rentalId: params.data.id,
      userId: req.user.id,
      userName,
      text: body.data.text,
    })
    .returning();

  // Notify listing owner if someone else commented
  if (rental.ownerId !== req.user.id) {
    await db.insert(notificationsTable).values({
      userId: rental.ownerId,
      text: `New message on "${rental.title}" from ${userName}`,
    });
  }

  const result = AddRentalCommentResponse.parse({
    id: comment.id,
    rental_id: comment.rentalId,
    user_id: comment.userId,
    user_name: comment.userName ?? null,
    text: comment.text,
    created_at: comment.createdAt.toISOString(),
  });

  res.status(201).json(result);
});

export default router;
