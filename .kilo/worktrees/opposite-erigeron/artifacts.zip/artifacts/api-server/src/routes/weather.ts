import { Router, type IRouter } from "express";
import { GetWeatherResponse } from "@workspace/api-zod";

const router: IRouter = Router();

// Simulated weather data for Finnish coastal cities
// In production this would call Ilmatieteen laitos (FMI) open data API
function getWeatherForCity(city: string) {
  const now = new Date();
  const month = now.getMonth(); // 0=Jan

  // Seasonal water temp approximation for Gulf of Bothnia
  const waterTemp =
    month >= 5 && month <= 8
      ? 14 + Math.random() * 6   // 14–20°C summer
      : month >= 9 || month <= 3
      ? 2 + Math.random() * 4    // 2–6°C winter
      : 8 + Math.random() * 6;   // 8–14°C spring/autumn

  const windMs = 1.5 + Math.random() * 8;
  const pressure = 995 + Math.random() * 30;
  const airTemp =
    month >= 5 && month <= 8
      ? 15 + Math.random() * 12
      : month >= 10 || month <= 2
      ? -10 + Math.random() * 15
      : 3 + Math.random() * 10;

  // Fishing index logic: best when pressure stable 1005-1020, wind < 4, water warm
  let fishing_index: "poor" | "fair" | "good" | "excellent";
  if (windMs < 3 && pressure > 1005 && pressure < 1020 && waterTemp > 12) {
    fishing_index = "excellent";
  } else if (windMs < 6 && pressure > 995) {
    fishing_index = "good";
  } else if (windMs < 8) {
    fishing_index = "fair";
  } else {
    fishing_index = "poor";
  }

  const fishingLabels = {
    poor:      { ru: "Клёв: Плохой",      en: "Bite: Poor",      fi: "Kalastus: Huono" },
    fair:      { ru: "Клёв: Средний",     en: "Bite: Fair",      fi: "Kalastus: Kohtalainen" },
    good:      { ru: "Клёв: Хороший",     en: "Bite: Good",      fi: "Kalastus: Hyvä" },
    excellent: { ru: "Клёв: Отличный",    en: "Bite: Excellent",  fi: "Kalastus: Erinomainen" },
  };

  // Seasonal foraging tips
  const foragingTips = {
    ru:
      month >= 6 && month <= 8
        ? "Черника и брусника на пике — мхи, опушки леса"
        : month === 9
        ? "Сезон грибов: лисички, подосиновики, маслята"
        : month >= 10
        ? "Клюква на болотах"
        : "Сезон заготовок не начался",
    en:
      month >= 6 && month <= 8
        ? "Blueberries and lingonberries peak — mossy forest clearings"
        : month === 9
        ? "Mushroom season: chanterelles, porcini, slippery jacks"
        : month >= 10
        ? "Cranberries on the bogs"
        : "Foraging season not yet started",
    fi:
      month >= 6 && month <= 8
        ? "Mustikat ja puolukat huipussaan — sammaleiset metsänreunat"
        : month === 9
        ? "Sienisatokausi: kantarelli, herkkutatti, voitatti"
        : month >= 10
        ? "Karpalo suoalueilla"
        : "Keräilykausi ei ole vielä alkanut",
  };

  return {
    city,
    wind_ms: Math.round(windMs * 10) / 10,
    water_temp_c: Math.round(waterTemp * 10) / 10,
    pressure_hpa: Math.round(pressure),
    air_temp_c: Math.round(airTemp * 10) / 10,
    fishing_index,
    fishing_label_ru: fishingLabels[fishing_index].ru,
    fishing_label_en: fishingLabels[fishing_index].en,
    fishing_label_fi: fishingLabels[fishing_index].fi,
    foraging_tip_ru: foragingTips.ru,
    foraging_tip_en: foragingTips.en,
    foraging_tip_fi: foragingTips.fi,
  };
}

router.get("/v1/weather", async (req, res): Promise<void> => {
  const city = (req.query.city as string) || "Kokkola";
  const weather = getWeatherForCity(city);
  const result = GetWeatherResponse.parse(weather);
  res.json(result);
});

export default router;
