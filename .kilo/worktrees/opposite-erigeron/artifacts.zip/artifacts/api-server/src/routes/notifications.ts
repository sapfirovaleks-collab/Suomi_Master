import { Router, type IRouter } from "express";
import { db, notificationsTable } from "@workspace/db";
import { ListNotificationsResponse } from "@workspace/api-zod";
import { eq, desc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/v1/notifications", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const notifs = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, req.user.id))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(50);

  const result = ListNotificationsResponse.parse(
    notifs.map((n) => ({
      id: n.id,
      text: n.text,
      created_at: n.createdAt.toISOString(),
      read: n.read,
    }))
  );

  res.json(result);
});

export default router;
